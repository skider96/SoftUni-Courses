﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpinionPoll
{
    public class Person
    {
        private string name;
        private int age;
        private List<Person> people;


        public string Name { get; set; }

        public int Age { get; set; }


        public Person() //"No name" and age = 1
        {
            Name = name;
            Age = age;
            Name = "No name";
            Age = 1;
        }

        public Person(int age) : this() 
        {
            Age = age;
        }

        public Person(string name,int age)
        {
            Name = name;
            Age = age;
        }
    }
}
